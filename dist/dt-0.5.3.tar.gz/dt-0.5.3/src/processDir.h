/*****
                          processDir.h  -  process dir header
                             -------------------
    begin                : Tue Jun 21 2011
    copyright            : (C) 2011 by Ron Dilley
    email                : ron.dilley@uberadmin.com
 *****/

/*****
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *****/

#ifndef PROCESSDIR_DOT_H
#define PROCESSDIR_DOT_H

/****
 *
 * defines
 *
 ****/

#define FORMAT_VERSION "1"
#define MD5_HASH_LEN 16
#define TIME_DATE_LEN 22

/****
 *
 * includes
 *
 ****/

#ifdef HAVE_CONFIG_H
# include <config.h>
#endif

#include <sysdep.h>

#ifndef __SYSDEP_H__
# error something is messed up
#endif

#include <stdio.h>
#include <common.h>
#include "util.h"
#include "mem.h"
#include "hash.h"
#include "md5.h"

/****
 *
 * consts & enums
 *
 ****/

/****
 *
 * typedefs & structs
 *
 ****/

typedef struct {
  struct stat sb;
  unsigned char digest[16];
} metaData_t;

/****
 *
 * function prototypes
 *
 ****/

PUBLIC int processDir( char *dirStr );
int findMissingFiles( const struct hashRec_s *hashRec );
char *hash2hex(const char *hash, char *hashStr, int hLen );
int writeDirHash2File( const struct hash_s *dirHash, const char *base, const char *outFile );
int loadFile( const char *fName );
inline int processRecord( const char *fpath, const struct stat *sb, char mode, unsigned char *digest );

#endif /* PROCESSDIR_DOT_H */

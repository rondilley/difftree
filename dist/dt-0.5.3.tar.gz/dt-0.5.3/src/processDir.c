/*****
 *
 * $Id: processDir.c,v 1.25 2011/07/27 09:52:54 rdilley Exp $
 *
 * Copyright (c) 2011, Ron Dilley
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *   - Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *   - Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions and the following disclaimer in
 *     the documentation and/or other materials provided with the
 *     distribution.
 *   - Neither the name of Uberadmin/BaraCUDA/Nightingale nor the names of
 *     its contributors may be used to endorse or promote products derived
 *     from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 * HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED
 * TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *****/

/****
 *
 * includes
 *.
 ****/

#include "processDir.h"

/****
 *
 * local variables
 *
 ****/

PRIVATE char *cvsid = "$Id: processDir.c,v 1.25 2011/07/27 09:52:54 rdilley Exp $";
FILE *out;

/****
 *
 * global variables
 *
 ****/

/****
 *
 * external variables
 *
 ****/

extern int errno;
extern char **environ;
extern struct hash_s *baseDirHash;
extern struct hash_s *compDirHash;
extern int quit;
extern int baseDirLen;
extern int compDirLen;
extern char *baseDir;
extern char *compDir;
extern Config_t *config;

/****
 * 
 * functions
 *
 ****/

/****
 *
 * process FTW() record
 *
 * NOTE: This is a callback function
 *
 ****/

#define FTW_RECORD 0
#define FILE_RECORD 1

static int processFtwRecord(const char *fpath, const struct stat *sb, int tflag, struct FTW *ftwbuf) {
  return processRecord( fpath, sb, FTW_RECORD, NULL );
}

/****
 *
 * process record
 *
 ****/

inline int processRecord( const char *fpath, const struct stat *sb, char mode, unsigned char *digestPtr ) {
  struct hashRec_s *tmpRec;
  struct stat *tmpSb;
  metaData_t *tmpMD;
  char tmpBuf[1024];
  char diffBuf[4096];
  struct tm *tmPtr;
  MD5_CTX ctx;
  FILE *inFile;
  size_t rCount;
  unsigned char rBuf[16384];
  unsigned char digest[16];
  int tflag = sb->st_mode & S_IFMT;

  bzero( &ctx, sizeof( ctx ) );
  bzero( digest, sizeof( digest ) );
  bzero( rBuf, sizeof( rBuf ) );
  bzero( tmpBuf, sizeof( tmpBuf ) );
  bzero( diffBuf, sizeof( diffBuf ) );

  if ( strlen( fpath ) <= compDirLen ) {
    /* ignore the root */
    return( FTW_CONTINUE );
  }

  if ( quit ) {
    /* graceful shutdown */
    return( FTW_STOP );
  }

  if ( baseDirHash != NULL ) {
    /* compare */
    if ( config->debug >=  5 )
      printf( "DEBUG - [%s]\n", fpath+compDirLen );

    /* hash regular files */
    if ( config->hash && ( tflag EQ S_IFREG ) ) {
      if ( mode EQ FTW_RECORD ) {
#ifdef DEBUG
	if ( config->debug >= 3 )
	  printf( "DEBUG - Generating MD5 of file [%s]\n", fpath );
#endif
	MD5_Init( &ctx );
	if ( ( inFile = fopen( fpath, "r" ) ) EQ NULL ) {
	  fprintf( stderr, "ERR - Unable to open file [%s]\n", fpath );
	} else {
	  while( ( rCount = fread( rBuf, 1, sizeof( rBuf ), inFile ) ) > 0 ) {
#ifdef DEBUG
	    if ( config->debug >= 6 )
	      printf( "DEBUG - Read [%ld] bytes from [%s]\n", (long int)rCount, fpath );
#endif
	    MD5_Update( &ctx, rBuf, rCount );
	  }
	  fclose( inFile );
	  MD5_Final( digest, &ctx );
	}
      } else if ( mode EQ FILE_RECORD ) {
	if ( digestPtr != NULL ) {
#ifdef DEBUG
	  if ( config->debug >= 3 )
	    printf( "DEBUG - Loading previously generated MD5 of file [%s]\n", fpath );
#endif
	  XMEMCPY( digest, digestPtr, sizeof( digest ) );
	}
      } else {
	/* unknown record type */
      }
    }

    if ( ( tmpRec = getHashRecord( baseDirHash, fpath+compDirLen ) ) EQ NULL ) {
      printf( "+ %s [%s]\n",
	      (tflag == S_IFDIR) ?   "d"   : (tflag == S_IFSOCK) ? "sok" :
	      (tflag == S_IFBLK) ?  "blk"  : (tflag == S_IFREG) ?   "f" :
	      (tflag == S_IFCHR) ?  "chr"  : (tflag == S_IFLNK) ?  "sl" :
	      (tflag == S_IFIFO) ? "fifo" : "???",
	      fpath+compDirLen );
    } else {
#ifdef DEBUG
      if ( config->debug >= 3 )
	printf( "DEBUG - Found match, comparing metadata\n" );
#endif
      tmpMD = (metaData_t *)tmpRec->data;
      tmpSb = (struct stat *)&tmpMD->sb;

      if ( sb->st_size != tmpSb->st_size ) {
#ifdef HAVE_SNPRINTF
	snprintf( tmpBuf, sizeof( tmpBuf ), "s[%ld->%ld] ", (long int)tmpSb->st_size, (long int)sb->st_size );
#else
	sprintf( tmpBuf, "s[%ld->%ld] ", (long int)tmpSb->st_size, (long int)sb->st_size );
#endif

#ifdef HAVE_STRNCAT
	strncat( diffBuf, tmpBuf, sizeof( diffBuf ) );
#else
	strlcat( diffBuf, tmpBuf, sizeof( diffBuf ) );
#endif
      } else {
	if ( config->hash && ( tflag EQ S_IFREG ) ) {
	  if ( memcmp( tmpMD->digest, digest, sizeof( digest ) ) != 0 ) {
	    /* MD5 does not match */
#ifdef HAVE_SNPRINTF
	    snprintf( tmpBuf, sizeof( tmpBuf ), "md5[%s->", hash2hex( tmpMD->digest, rBuf, sizeof( digest ) ) );
#else
	    sprintf( tmpBuf, "md5[%s->", hash2hex( tmpMD->digest, rBuf, sizeof( digest ) ) );
#endif
#ifdef HAVE_STRNCAT
	    strncat( diffBuf, tmpBuf, sizeof( diffBuf ) );
#else
	    strlcat( diffBuf, tmpBuf, sizeof( diffBuf ) );
#endif
#ifdef HAVE_SNPRINTF
	    snprintf( tmpBuf, sizeof( tmpBuf ), "%s] ", hash2hex( digest, rBuf, sizeof( digest ) ) );
#else
	    sprintf( tmpBuf, "%s] ", hash2hex( digest, rBuf, sizeof( digest ) ) );
#endif
#ifdef HAVE_STRNCAT
	    strncat( diffBuf, tmpBuf, sizeof( diffBuf ) );
#else
	    strlcat( diffBuf, tmpBuf, sizeof( diffBuf ) );
#endif
	  }
	}
      }

      if ( !config->quick ) {
	/* do more testing */

	/* uid/gid */
	if ( sb->st_uid != tmpSb->st_uid ) {
#ifdef HAVE_SNPRINTF
	  snprintf( tmpBuf, sizeof( tmpBuf ), "u[%d>%d] ", tmpSb->st_uid, sb->st_uid );
#else
	  sprintf( tmpBuf, "u[%d>%d] ", tmpSb->st_uid, sb->st_uid );
#endif
#ifdef HAVE_STRNCAT
          strncat( diffBuf, tmpBuf, sizeof( diffBuf ) );
#else
	  strlcat( diffBuf, tmpBuf, sizeof( diffBuf ) );
#endif
	}
	if ( sb->st_gid != tmpSb->st_gid ) {
#ifdef HAVE_SNPRINTF
	  snprintf( tmpBuf, sizeof( tmpBuf ), "g[%d>%d] ", tmpSb->st_gid, sb->st_gid );
#else
	  sprintf( tmpBuf, "g[%d>%d] ", tmpSb->st_gid, sb->st_gid );
#endif

#ifdef HAVE_STRNCAT
          strncat( diffBuf, tmpBuf, sizeof( diffBuf ) );
#else
	  strlcat( diffBuf, tmpBuf, sizeof( diffBuf ) );
#endif
	}

	/* file type */
	if ( ( sb->st_mode & S_IFMT ) != ( tmpSb->st_mode & S_IFMT ) ) {
#ifdef HAVE_SNPRINTF
	  snprintf( tmpBuf, sizeof( tmpBuf ), "t[%s->%s] ",
#else
	  sprintf( tmpBuf, "t[%s->%s] ",
#endif
		   ((tmpSb->st_mode & S_IFMT) == S_IFDIR) ?   "d"   : ((tmpSb->st_mode & S_IFMT) == S_IFSOCK) ? "sok" :
		   ((tmpSb->st_mode & S_IFMT) == S_IFBLK) ?  "blk"  : ((tmpSb->st_mode & S_IFMT) == S_IFREG) ?   "f" :
		   ((tmpSb->st_mode & S_IFMT) == S_IFCHR) ?  "chr"  : ((tmpSb->st_mode & S_IFMT) == S_IFLNK) ?  "sl" :
		   ((tmpSb->st_mode & S_IFMT) == S_IFIFO) ? "fifo" : "???",
		   ((sb->st_mode & S_IFMT) == S_IFDIR) ?   "d"   : ((sb->st_mode & S_IFMT) == S_IFSOCK) ? "sok" :
		   ((sb->st_mode & S_IFMT) == S_IFBLK) ?  "blk"  : ((sb->st_mode & S_IFMT) == S_IFREG) ?   "f" :
		   ((sb->st_mode & S_IFMT) == S_IFCHR) ?  "chr"  : ((sb->st_mode & S_IFMT) == S_IFLNK) ?  "sl" :
		   ((sb->st_mode & S_IFMT) == S_IFIFO) ? "fifo" : "???" );

#ifdef HAVE_STRNCAT
          strncat( diffBuf, tmpBuf, sizeof( diffBuf ) );
#else
	  strlcat( diffBuf, tmpBuf, sizeof( diffBuf ) );
#endif
	}

	/* permissions */
	if ( ( sb->st_mode & 0xffff ) != ( tmpSb->st_mode & 0xffff ) ) {
#ifdef HAVE_SNPRINTF
	  snprintf( tmpBuf, sizeof( tmpBuf ), "p[%c%c%c%c%c%c%c%c%c->%c%c%c%c%c%c%c%c%c] ",
#else
	  sprintf( tmpBuf, "p[%c%c%c%c%c%c%c%c%c->%c%c%c%c%c%c%c%c%c] ",
#endif
		   (tmpSb->st_mode & S_IRUSR ) ? 'r' : '-',
		   (tmpSb->st_mode & S_IWUSR ) ? 'w' : '-',
		   (tmpSb->st_mode & S_ISUID ) ? 's' : (tmpSb->st_mode & S_IXUSR) ? 'x' : '-',
		   (tmpSb->st_mode & S_IRGRP ) ? 'r' : '-',
		   (tmpSb->st_mode & S_IWGRP ) ? 'w' : '-',
		   (tmpSb->st_mode & S_ISGID ) ? 's' : (tmpSb->st_mode & S_IXGRP) ? 'x' : '-',
		   (tmpSb->st_mode & S_IROTH ) ? 'r' : '-',
		   (tmpSb->st_mode & S_IWOTH ) ? 'w' : '-',
		   (tmpSb->st_mode & S_ISVTX ) ? 's' : (tmpSb->st_mode & S_IXOTH) ? 'x' : '-',
		   (sb->st_mode & S_IRUSR ) ? 'r' : '-',
		   (sb->st_mode & S_IWUSR ) ? 'w' : '-',
		   (sb->st_mode & S_ISUID ) ? 's' : (sb->st_mode & S_IXUSR) ? 'x' : '-',
		   (sb->st_mode & S_IRGRP ) ? 'r' : '-',
		   (sb->st_mode & S_IWGRP ) ? 'w' : '-',
		   (sb->st_mode & S_ISGID ) ? 's' : (sb->st_mode & S_IXGRP) ? 'x' : '-',
		   (sb->st_mode & S_IROTH ) ? 'r' : '-',
		   (sb->st_mode & S_IWOTH ) ? 'w' : '-',
		   (sb->st_mode & S_ISVTX ) ? 's' : (sb->st_mode & S_IXOTH) ? 'x' : '-' );
#ifdef HAVE_STRNCAT
          strncat( diffBuf, tmpBuf, sizeof( diffBuf ) );
#else
	  strlcat( diffBuf, tmpBuf, sizeof( diffBuf ) );
#endif
	}

	if ( sb->st_mtime != tmpSb->st_mtime ) {
	  tmPtr = localtime( &tmpSb->st_mtime );
#ifdef HAVE_SNPRINTF
	  snprintf( tmpBuf, sizeof( tmpBuf ), "mt[%04d/%02d/%02d@%02d:%02d:%02d->",
#else
	  sprintf( tmpBuf, "mt[%04d/%02d/%02d@%02d:%02d:%02d->",
#endif
		   tmPtr->tm_year+1900, tmPtr->tm_mon+1, tmPtr->tm_mday,
		   tmPtr->tm_hour, tmPtr->tm_min, tmPtr->tm_sec );
#ifdef HAVE_STRNCAT
          strncat( diffBuf, tmpBuf, sizeof( diffBuf ) );
#else
	  strlcat( diffBuf, tmpBuf, sizeof( diffBuf ) );
#endif
	  tmPtr = localtime( &sb->st_mtime );
#ifdef HAVE_SNPRINTF
	  snprintf( tmpBuf, sizeof( tmpBuf ), "%04d/%02d/%02d@%02d:%02d:%02d] ",
#else
	  sprintf( tmpBuf, "%04d/%02d/%02d@%02d:%02d:%02d] ",
#endif
		   tmPtr->tm_year+1900, tmPtr->tm_mon+1, tmPtr->tm_mday,
		   tmPtr->tm_hour, tmPtr->tm_min, tmPtr->tm_sec );
#ifdef HAVE_STRNCAT
          strncat( diffBuf, tmpBuf, sizeof( diffBuf ) );
#else
	  strlcat( diffBuf, tmpBuf, sizeof( diffBuf ) );
#endif
	}
      }

      if ( strlen( diffBuf ) ) {
	printf( "%s%s [%s]\n", diffBuf,
		(tflag == S_IFDIR) ?   "d"   : (tflag == S_IFSOCK) ? "sok" :
		(tflag == S_IFBLK) ?  "blk"  : (tflag == S_IFREG) ?   "f" :
		(tflag == S_IFCHR) ?  "chr"  : (tflag == S_IFLNK) ?  "sl" :
		(tflag == S_IFIFO) ? "fifo" : "???",
		fpath );
      }
#ifdef DEBUG
      else {
	if ( config->debug > 4 )
	  printf( "DEBUG - Record matches\n" );
      }
#endif

    }

    /* store file metadata */
    tmpMD = (metaData_t *)XMALLOC( sizeof( metaData_t ) );
    XMEMSET( tmpMD, 0, sizeof( metaData_t ) );
    /* save the hash for regular files */
    if ( config->hash && ( tflag EQ S_IFREG ) ) {
#ifdef DEBUG
      if ( config->debug >= 3 )
	printf( "DEBUG - Adding hash [%s] for file [%s]\n", hash2hex( digest, rBuf, sizeof( digest ) ), fpath );
#endif
      XMEMCPY( tmpMD->digest, digest, sizeof( digest ) );
    }
    XMEMCPY( (void *)&tmpMD->sb, (void *)sb, sizeof( struct stat ) );
    addUniqueHashRec( compDirHash, fpath+compDirLen, strlen( fpath+compDirLen ), tmpMD );
    /* check to see if the hash should be grown */
    compDirHash = dyGrowHash( compDirHash );
  } else {
    /* store file metadata */
    tmpMD = (metaData_t *)XMALLOC( sizeof( metaData_t ) );
    XMEMSET( tmpMD, 0, sizeof( metaData_t ) );

    /* hash regular files */
    if ( config->hash && ( tflag EQ S_IFREG ) ) {
      if ( mode EQ FTW_RECORD ) {
#ifdef DEBUG
	if ( config->debug >= 3 )
	  printf( "DEBUG - Generating MD5 of file [%s]\n", fpath );
#endif
	MD5_Init( &ctx );
	if ( ( inFile = fopen( fpath, "r" ) ) EQ NULL ) {
	  fprintf( stderr, "ERR - Unable to open file [%s]\n", fpath );
	} else {
	  while( ( rCount = fread( rBuf, 1, sizeof( rBuf ), inFile ) ) > 0 ) {
#ifdef DEBUG
	    if ( config->debug >= 6 )
	      printf( "DEBUG - Read [%ld] bytes from [%s]\n", (long int)rCount, fpath );
#endif
	    MD5_Update( &ctx, rBuf, rCount );
	  }
	  fclose( inFile );
	  MD5_Final( digest, &ctx );
	}
      } else if ( mode EQ FILE_RECORD ) {
	if ( digestPtr != NULL ) {
#ifdef DEBUG
	  if ( config->debug >= 3 )
	    printf( "DEBUG - Loading previously generated MD5 of file [%s]\n", fpath );
#endif
	  XMEMCPY( digest, digestPtr, sizeof( digest ) );
	}
      } else {
	/* unknown record type */
      }
      XMEMCPY( tmpMD->digest, digest, sizeof( digest ) );
    }

    XMEMCPY( (void *)&tmpMD->sb, (void *)sb, sizeof( struct stat ) );
#ifdef DEBUG
    if ( config->debug >= 5 )
      printf( "DEBUG - Adding RECORD\n" );
#endif
    addUniqueHashRec( compDirHash, fpath+compDirLen, strlen( fpath+compDirLen ), tmpMD );
    /* check to see if the hash should be grown */
    compDirHash = dyGrowHash( compDirHash );
  }

  return( FTW_CONTINUE );
}

/****
 *
 * process directory tree
 *
 ****/

PUBLIC int processDir( char *dirStr ) {
  struct stat sb;
  int tflag, ret;

  if ( lstat( dirStr, &sb ) EQ 0 ) {
    /* file exists, make sure it is a file */
    tflag = sb.st_mode & S_IFMT;
    if ( tflag EQ S_IFREG ) {
      /* process file */
      printf( "Processing file [%s]\n", dirStr );
      if ( ( ret = loadFile( dirStr ) ) EQ (-1) ) {
		fprintf( stderr, "ERR - Problem while loading file\n" );
		return( FAILED );
	  } else if ( ret EQ FTW_STOP ) {
		fprintf( stderr, "ERR - loadFile() was interrupted by a signal\n");
		return( FAILED );
	  }	
    } else if ( tflag EQ S_IFDIR ) {
      /* process directory */
      printf( "Processing dir [%s]\n", dirStr );
      
#ifdef HAVE_NFTW
      if ( ( ret = nftw( dirStr, processFtwRecord, 20, FTW_PHYS | FTW_ACTIONRETVAL ) ) EQ (-1) ) {
	fprintf( stderr, "ERR - Unable to open dir [%s]\n", dirStr );
	return ( FAILED );
      } else if ( ret EQ FTW_STOP ) {
	fprintf( stderr, "ERR - nftw() was interrupted by a signal\n" );
	return( FAILED );
      }
#else
      printf( "I really should write a drop in replacement for nftw()\n" );
#endif

      /* write data to file */
      if ( config->outfile != NULL ) {
	writeDirHash2File( compDirHash, compDir, config->outfile );
	/* only write out the first read dir */
	XFREE( config->outfile );
	config->outfile = NULL;
      }

#ifdef DEBUG
      if ( config->debug >= 2 )
	printf( "DEBUG - Finished processing dir [%s]\n", dirStr );
#endif
    } else {
      fprintf( stderr, "ERR - [%s] is not a regular file or a directory\n", dirStr );
      return( FAILED );
    }
  } else {
    fprintf( stderr, "ERR - Unable to stat file [%s]\n", dirStr );
    return( FAILED );
  }

  return( TRUE );
}

/****
 *
 * check for missing files
 *
 ****/

int findMissingFiles( const struct hashRec_s *hashRec ) {
  struct hashRec_s *tmpRec;
  metaData_t *tmpMD;
  struct stat *tmpSb;
  int tflag;

#ifdef DEBUG
  if ( config->debug >= 3 )
    printf( "DEBUG - Searching for [%s]\n", hashRec->keyString );
#endif

  if ( ( tmpRec = getHashRecord( compDirHash, hashRec->keyString ) ) EQ NULL ) {
    tmpMD = (metaData_t *)hashRec->data;
    tmpSb = (struct stat *)&tmpMD->sb;
    tflag = tmpSb->st_mode & S_IFMT;
    printf( "- %s [%s]\n", 
	    (tflag == S_IFDIR) ?   "d"   : (tflag == S_IFSOCK) ? "sok" :
	    (tflag == S_IFBLK) ?  "blk"  : (tflag == S_IFREG) ?   "f" :
	    (tflag == S_IFCHR) ?  "chr"  : (tflag == S_IFLNK) ?  "sl" :
	    (tflag == S_IFIFO) ? "fifo" : "???",
	    hashRec->keyString );
  }
#ifdef DEBUG
  else
    if ( config->debug >= 4 )
      printf( "DEBUG - Record found [%s]\n", hashRec->keyString );
#endif

  /* can use this later to interrupt traversing the hash */
  if ( quit )
    return( TRUE );
  return( FALSE );
}

/****
 *
 * convert hash to hex
 *
 ****/

char *hash2hex(const char *hash, char *hashStr, int hLen ) {
  int i;
  char hByte[3];
  bzero( hByte, sizeof( hByte ) );
	hashStr[0] = 0;
	
  for( i = 0; i < hLen; i++ ) {
    snprintf( hByte, sizeof(hByte), "%02x", hash[i] & 0xff );
#ifdef HAVE_STRNCAT
    strncat( hashStr, hByte, hLen*2 );
#else
    strlcat( hashStr, hByte, hLen*2 );
#endif
  }

  return hashStr;
}

/*****
 *
 * write directory tree record to file
 *
 *****/

int writeRecord2File( const struct hashRec_s *hashRec ) {
  metaData_t *tmpMD;
  struct stat *tmpSb;
  char tmpBuf[1024];
  int tflag;
  struct tm *tmPtr;

  tmpMD = (metaData_t *)hashRec->data;
  tmpSb = (struct stat *)&tmpMD->sb;
  tflag = tmpSb->st_mode & S_IFMT;

  if ( strlen( hashRec->keyString ) <= 0 )
    return FAILED;

  fprintf( out, "KEY=\"%s\" ", hashRec->keyString );
  fprintf( out, "TYPE=%s ",
	   (tflag == S_IFDIR) ?   "d"   : (tflag == S_IFSOCK) ? "sok" :
	   (tflag == S_IFBLK) ?  "blk"  : (tflag == S_IFREG) ?   "f" :
	   (tflag == S_IFCHR) ?  "chr"  : (tflag == S_IFLNK) ?  "sl" :
	   (tflag == S_IFIFO) ? "fifo" : "???" );
  fprintf( out, "SIZE=%ld ", (long int)tmpSb->st_size );
  fprintf( out, "UID=%d ", tmpSb->st_uid );
  fprintf( out, "GID=%d ", tmpSb->st_gid );
  fprintf( out, "PERM=%x%x%x%x ",
	   tmpSb->st_mode >> 9 & S_IRWXO,
	   tmpSb->st_mode >> 6 & S_IRWXO,
	   tmpSb->st_mode >> 3 & S_IRWXO,
	   tmpSb->st_mode & S_IRWXO );
  fprintf( out, "MTIME=%ld ", tmpSb->st_mtime );
  fprintf( out, "ATIME=%ld ", tmpSb->st_atime );
  fprintf( out, "CTIME=%ld ", tmpSb->st_ctime );
  fprintf( out, "INODE=%ld ", (long int)tmpSb->st_ino );
  fprintf( out, "HLINKS=%d ", tmpSb->st_nlink );
  fprintf( out, "BLOCKS=%ld ", (long int)tmpSb->st_blocks );
  if ( config->hash && ( tflag EQ S_IFREG ) )
    fprintf( out, "MD5=\"%s\" ", hash2hex( tmpMD->digest, tmpBuf, 16 ) );
  fprintf( out, "\n" );

  /* can use this later to interrupt traversing the hash */
  return FALSE;
}

/*****
 *
 * write contents of directory hash to file
 *
 *****/

int writeDirHash2File( const struct hash_s *dirHash, const char *base, const char *outFile ) {
  struct stat sb;
  int tflag;
  struct tm *tmPtr;

  if ( lstat( outFile, &sb ) EQ 0 ) {
    /* file exists, make sure it is a file */
    tflag = sb.st_mode & S_IFMT;
    if ( tflag != S_IFREG ) {
      fprintf( stderr, "ERR - Unable to overwrite non-file [%s]\n", outFile);
      return( FAILED );
    }
  }
	
  /* open the file for writing */
  if ( ( out = fopen( outFile, "w" ) ) EQ (FILE *)0 ) {
    fprintf( stderr, "ERR - Unable to open file [%s] to write\n", outFile );
    return FAILED;
  }

  /* write the header info */
  fprintf( out, "%%DIFFTREE-%s\n", VERSION );
  fprintf( out, "VER=%s\n", FORMAT_VERSION );
  fprintf( out, "BASE=%s\n", base );
  fprintf( out, "MODE=%s\n", (config->hash) ? "HASH" : ( config->quick ) ? "QUICK" : "NORMAL" );
  tmPtr = localtime( &config->current_time );
  fprintf( out, "START=\"%04d/%02d/%02d@%02d:%02d:%02d\"\n",
	   tmPtr->tm_year+1900, tmPtr->tm_mon+1, tmPtr->tm_mday,
	   tmPtr->tm_hour, tmPtr->tm_min, tmPtr->tm_sec );

  /* dump all directory tree records to a file */
  traverseHash( dirHash, writeRecord2File );

  fprintf( out, "RECORDS=%ld\n", (long int)dirHash->totalRecords );

  /* done */
  fclose( out );

  return TRUE;
}

/****
 *
 * load file and process each record
 *
 ****/

int loadFile( const char *fName ) {
  FILE *inFile;
  char inBuf[8192];
  char keyString[MAXPATHLEN+1];
  char startDate[128];
  char hByte[3];
  char *strPtr;
  unsigned char digest[16]; /* MD5 */
  struct stat sb;
  size_t count = 0, rCount;
  int i, dPos, lPos, ret, tflag;
  int tMon = 0, tDay = 0, tYear = 0, tHour = 0, tMin = 0, tSec = 0, tType = 0, tPerm = 0;
  struct tm tmb;
  struct tm *tmPtr;

  if ( ( inFile = fopen( fName, "r" ) ) EQ NULL ) {
    fprintf( stderr, "ERR - Unable to open file [%s] for reading\n", fName );
    return( FAILED );
  }

  XMEMSET( hByte, 0, sizeof( hByte ) );
  XMEMSET( inBuf, 0, sizeof( inBuf ) );
  XMEMSET( startDate, 0, sizeof( startDate ) );

  /****
   *
   * read the headers
   *
   ****/

  /* DIFFTREE preamble */
  if ( fscanf( inFile, "%%DIFFTREE-%s\n", inBuf ) != 1 ) {
    fprintf( stderr, "ERR - File does not appear to be a DIFFTREE file\n" );
    fclose( inFile );
    return( FAILED );
  }

  /* get to parsing */
  initParser();
  
  /* File format version */
  if ( fgets( inBuf, sizeof( inBuf ), inFile ) EQ NULL ) {
    fprintf( stderr, "ERR - Unable to read line from input file\n" );
    deInitParser();
    fclose( inFile );
    return( FAILED );
  }
  if ( ( ret = parseLine( inBuf ) ) != 2 ) {
    printf( "ERR - Malformed record line - [%d] fields\n", ret );
  } else {
    for( i = 0; i < ret; i=i+2 ) {
      /* load the fields */
      getParsedField( inBuf, sizeof( inBuf ), i );
      if ( strlen( inBuf ) <= 0 ) {
	/* LHS (key) is zero length */
	fprintf( stderr, "ERR - Key is corrupt\n" );
      } else if ( strcmp( inBuf, "VER" ) EQ 0 ) {
		getParsedField( inBuf, sizeof( inBuf ), i+1 );
	if ( strlen( inBuf ) > 0 ) {
	  if ( atoi( inBuf ) != 1 ) {
	    fprintf( stderr, "ERR - File version format [%s] is not compatible with this version of difftree\n", inBuf );
	    deInitParser();
	    fclose( inFile );
	    return( FAILED );
	  }
#ifdef DEBUG
	  if ( config->debug >= 2 )
	    printf( "DEBUG - File Version: %s\n", inBuf );
#endif
	} else {
	  fprintf( stderr, "ERR - Version information corrupted\n" );
	  deInitParser();
	  fclose( inFile );
	  return( FAILED );
	}
      } else {
	fprintf( stderr, "ERR - File version missing, file may be corrupt\n" );
	deInitParser();
	fclose( inFile );
	return( FAILED );
      }
    }
  }
  
  /* Base directory to prepend to all records */
  if ( fgets( inBuf, sizeof( inBuf ), inFile ) EQ NULL ) {
    fprintf( stderr, "ERR - Unable to read line from input file\n" );
    return( FAILED );
  }
  if ( ( ret = parseLine( inBuf ) ) != 2 ) {
    printf( "ERR - Malformed record line - [%d] fields\n", ret );
  } else {
    for( i = 0; i < ret; i=i+2 ) {
      /* load the fields */
      getParsedField( inBuf, sizeof( inBuf ), i );
      if ( strlen( inBuf ) <= 0 ) {
	/* LHS (key) is zero length */
	fprintf( stderr, "ERR - Key is corrupt\n" );
      } else if ( strcmp( inBuf, "BASE" ) EQ 0 ) {
	getParsedField( inBuf, sizeof( inBuf ), i+1 );
	if ( strlen( inBuf ) > 0 ) {
	  XSTRNCPY( compDir, inBuf, PATH_MAX );
	  compDirLen = strlen( compDir );
#ifdef DEBUG
	  if ( config->debug >= 2 )
	    printf( "DEBUG - Base Dir: %s\n", compDir );
#endif
	} else {
	  fprintf( stderr, "ERR - Base directory corrupted\n" );
	    deInitParser();
	  fclose( inFile );
	  return( FAILED );
	}
      } else {
	fprintf( stderr, "ERR - Base directory missing, file may be corrupt\n" );
	    deInitParser();
	fclose( inFile );
	return( FAILED );
      }
    }
  }

  /* Scan mode */
  if ( fgets( inBuf, sizeof( inBuf ), inFile ) EQ NULL ) {
    fprintf( stderr, "ERR - Unable to read line from input file\n" );
    deInitParser();
    fclose( inFile );
    return( FAILED );
  }
  if ( ( ret = parseLine( inBuf ) ) != 2 ) {
    printf( "ERR - Malformed record line - [%d] fields\n", ret );
  } else {
    for( i = 0; i < ret; i=i+2 ) {
      /* load the fields */
      getParsedField( inBuf, sizeof( inBuf ), i );
      if ( strlen( inBuf ) <= 0 ) {
	/* LHS (key) is zero length */
	fprintf( stderr, "ERR - Key is corrupt\n" );
      } else if ( strcmp( inBuf, "MODE" ) EQ 0 ) {
	getParsedField( inBuf, sizeof( inBuf ), i+1 );
	if ( strncmp( inBuf, "QUICK", sizeof( inBuf ) ) EQ 0 ) {
	  if ( ! config->quick ) {
	    fprintf( stderr, "ERR - The file's mode is not compatible with the current mode [%s->%s]\n",
		     inBuf, (config->hash) ? "HASH" : "NORMAL" );
	    deInitParser();
	    fclose( inFile );
	    return( FAILED );
	  }
	} else if ( strncmp( inBuf, "NORMAL", sizeof( inBuf ) ) EQ 0 ) {
	  if ( config->hash ) {
	    fprintf( stderr, "ERR - The file's mode is not compatible with the current mode [%s->HASH]\n", inBuf );
	    deInitParser();
	    fclose( inFile );
	    return( FAILED );
	  }
	} else if ( strncmp( inBuf, "HASH", sizeof( inBuf ) ) EQ 0 ) {
	  /* compatible with other modes */
	} else {
	  /* unknown hash mode */
	  fprintf( stderr, "ERR - Unknown mode, file may be corrupt\n" );
	  deInitParser();
	  fclose( inFile );
	  return( FAILED );
	}
#ifdef DEBUG
	if ( config->debug >= 2 )
	  printf( "DEBUG - Mode: %s\n", inBuf );
#endif
      } else {
	fprintf( stderr, "ERR - Mode is corrupted\n" );
	deInitParser();
	fclose( inFile );
	return( FAILED );
      }
    }
  }

  /* Start time */
  if ( fgets( inBuf, sizeof( inBuf ), inFile ) EQ NULL ) {
    fprintf( stderr, "ERR - Unable to read line from input file\n" );
    deInitParser();
    fclose( inFile );
    return( FAILED );
  }
  if ( ( ret = parseLine( inBuf ) ) != 2 ) {
    printf( "ERR - Malformed record line - [%d] fields\n", ret );
  } else {
    for( i = 0; i < ret; i=i+2 ) {
      /* load the fields */
      getParsedField( inBuf, sizeof( inBuf ), i );
      if ( strlen( inBuf ) <= 0 ) {
	/* LHS (key) is zero length */
	fprintf( stderr, "ERR - Key is corrupt\n" );
      } else if ( strcmp( inBuf, "START" ) EQ 0 ) {
	getParsedField( inBuf, sizeof( inBuf ), i+1 );
	if ( strlen( inBuf ) > 0 ) {
	  XSTRNCPY( startDate, inBuf, sizeof( startDate ) );
	} else {
	  fprintf( stderr, "ERR - Start time is corrupted\n" );
	  deInitParser();
	  fclose( inFile );
	  return( FAILED );
	}
#ifdef DEBUG
	if ( config->debug >= 2 )
	  printf( "DEBUG - Start: %s\n", startDate );
#endif
      } else {
	fprintf( stderr, "ERR - Start is corrupted\n" );
	deInitParser();
	fclose( inFile );
	return( FAILED );
      }
    }
  }

  /****
   *
   * read all of the file records
   *
   ****/

  while( fgets( inBuf, sizeof( inBuf ), inFile ) != NULL ) {
    if ( quit ) {
      deInitParser();
      fclose( inFile );
      return( FTW_STOP );
    }

    /**** get to work on that line ****/
    if ( ( ret = parseLine( inBuf ) ) EQ 2 ) {
      for ( i = 0; i < ret; i+=2 ) {
	getParsedField( inBuf, sizeof( inBuf ), i );
	if ( strlen( inBuf ) <= 0 ) {
	  /* LHS (key) is zero length */
	  fprintf( stderr, "ERR - Key is corrupt\n" );
	} else if ( strcmp( inBuf, "RECORDS" ) EQ 0 ) {
	  getParsedField( inBuf, sizeof( inBuf ), i+1 );
	  if ( strlen( inBuf ) > 0 ) {
	    if ( ( rCount = atol( inBuf ) ) != compDirHash->totalRecords )
	      fprintf( stderr, "ERR - [%ld] records in file, [%ld] records in hash\n", (long int)rCount, (long int)compDirHash->totalRecords );
#ifdef DEBUG
	    if ( config->debug >= 2 )
	    printf( "DEBUG - Records: %ld\n", rCount );
#endif
	  } else {
	    fprintf( stderr, "ERR - Record count is corrupted\n" );
	    deInitParser();
	    fclose( inFile );
	    return( FAILED );
	  }
	} else {
	  fprintf( stderr, "ERR - Record is corrupted\n" );
	  deInitParser();
	  fclose( inFile );
	  return( FAILED );
	}
      }
    } else if ( ( ret != 24 ) && ( ret != 26 ) ) {
      printf( "ERR - Malformed record line - [%d] fields\n", ret );
    } else {
      count++;
      for( i = 0; i < ret; i=i+2 ) {
	/* load the fields */
	getParsedField( inBuf, sizeof( inBuf ), i );
	if ( strlen( inBuf ) <= 0 ) {
	  /* LHS (key) is zero length */
	  fprintf( stderr, "ERR - Key is corrupt\n" );
	} else if ( strcmp( inBuf, "KEY" ) EQ 0 ) {
	  getParsedField( inBuf, sizeof( inBuf ), i+1 );
	  if ( strlen( inBuf ) > 0 ) {
	    snprintf( keyString, sizeof( keyString ), "%s%s", compDir, inBuf );
#ifdef DEBUG
	    if ( config->debug >= 5 )
	      printf( "DEBUG - KEY=%s\n", keyString );
#endif
	  }
	} else if ( strcmp( inBuf, "TYPE" ) EQ 0 ) {
	  getParsedField( inBuf, sizeof( inBuf ), i+1 );
	  if ( inBuf[0] EQ 'f' )
	    if ( inBuf[1] EQ 'i' )	  
	      tType = S_IFIFO;
	    else
	      tType = S_IFREG;
	  else if ( inBuf[0] EQ 'd' )
	    tType =  S_IFDIR;
	  else if ( inBuf[0] EQ 'b' )
	    tType = S_IFBLK;
	  else if ( inBuf[0] EQ 'c' )
	    tType =  S_IFCHR;
	  else if ( inBuf[0] EQ 's' )
	    if ( inBuf[1] EQ 'l' )
	      tType = S_IFLNK;
	    else
	      tType = S_IFSOCK;
#ifdef DEBUG
	  if ( config->debug >= 5 ) {
	    tflag = tType & S_IFMT;
	    printf( "DEBUG - TYPE=%s\n",
		    (tflag == S_IFDIR) ?   "d"   : (tflag == S_IFSOCK) ? "sok" :
		    (tflag == S_IFBLK) ?  "blk"  : (tflag == S_IFREG) ?   "f" :
		    (tflag == S_IFCHR) ?  "chr"  : (tflag == S_IFLNK) ?  "sl" :
		    (tflag == S_IFIFO) ? "fifo" : "???" );
	  }
#endif
	} else if ( strcmp( inBuf, "SIZE" ) EQ 0 ) {
	  getParsedField( inBuf, sizeof( inBuf ), i+1 );
	  sb.st_size = (off_t)atol( inBuf );
#ifdef DEBUG
	  if ( config->debug >= 5 )
	    printf( "DEBUG - SIZE=%ld\n", (long int)sb.st_size );
#endif
	} else if ( strcmp( inBuf, "UID" ) EQ 0 ) {
 	  getParsedField( inBuf, sizeof( inBuf ), i+1 );
	  sb.st_uid = (uid_t)atoi( inBuf );
#ifdef DEBUG
	  if ( config->debug >= 5 )
	    printf( "DEBUG - UID=%d\n", sb.st_uid );
#endif
	} else if ( strcmp( inBuf, "GID" ) EQ 0 ) {
 	  getParsedField( inBuf, sizeof( inBuf ), i+1 );
	  sb.st_gid = (gid_t)atoi( inBuf );
#ifdef DEBUG
	  if ( config->debug >= 5 )
	    printf( "DEBUG - GID=%d\n", sb.st_gid );
#endif
	} else if ( strcmp( inBuf, "PERM" ) EQ 0 ) {
 	  getParsedField( inBuf, sizeof( inBuf ), i+1 );
	  tPerm = strtoul( inBuf, NULL, 8 );
#ifdef DEBUG
	  if ( config->debug >= 5 )
	    printf( "DEBIG - PERM=%x%x%x%x\n",
		    tPerm >> 9 & S_IRWXO,
		    tPerm >> 6 & S_IRWXO,
		    tPerm >> 3 & S_IRWXO,
		    tPerm & S_IRWXO );
#endif
	} else if ( strcmp( inBuf, "MTIME" ) EQ 0 ) {
 	  getParsedField( inBuf, sizeof( inBuf ), i+1 );
	  sb.st_mtime = atol( inBuf );
#ifdef DEBUG
	  if ( config->debug >= 5 ) {
	    tmPtr = localtime( &sb.st_mtime );
	    printf( "DEBUG - MTIME=%04d/%02d/%02d@%02d:%02d:%02d%s\n",
		    tmPtr->tm_year+1900, tmPtr->tm_mon+1, tmPtr->tm_mday,
		    tmPtr->tm_hour, tmPtr->tm_min, tmPtr->tm_sec, (tmPtr->tm_isdst) ? "DST" : "---" );
	  }
#endif
	} else if ( strcmp( inBuf, "ATIME" ) EQ 0 ) {
 	  getParsedField( inBuf, sizeof( inBuf ), i+1 );
	  sb.st_atime = atol( inBuf );
#ifdef DEBUG
	  if ( config->debug >= 5 ) {
	    tmPtr = localtime( &sb.st_atime );
	    printf( "DEBUG - ATIME=%04d/%02d/%02d@%02d:%02d:%02d%s\n",
		    tmPtr->tm_year+1900, tmPtr->tm_mon+1, tmPtr->tm_mday,
		    tmPtr->tm_hour, tmPtr->tm_min, tmPtr->tm_sec, (tmPtr->tm_isdst) ? "DST" : "---" );
	  }
#endif
	} else if ( strcmp( inBuf, "CTIME" ) EQ 0 ) {
 	  getParsedField( inBuf, sizeof( inBuf ), i+1 );
	  sb.st_ctime = atol( inBuf );
#ifdef DEBUG
	  if ( config->debug >= 5 ) {
	    tmPtr = localtime( &sb.st_ctime );
	    printf( "DEBUG - CTIME=%04d/%02d/%02d@%02d:%02d:%02d%s\n",
		    tmPtr->tm_year+1900, tmPtr->tm_mon+1, tmPtr->tm_mday,
		    tmPtr->tm_hour, tmPtr->tm_min, tmPtr->tm_sec, (tmPtr->tm_isdst) ? "DST" : "---" );
	  }
#endif
	} else if ( strcmp( inBuf, "INODE" ) EQ 0 ) {
	  getParsedField( inBuf, sizeof( inBuf ), i+1 );
	  sb.st_ino = (ino_t)atol( inBuf );
#ifdef DEBUG
	  if ( config->debug >= 5 )
	    printf( "DEBUG - INODE=%ld\n", (long int)sb.st_ino );
#endif
	} else if ( strcmp( inBuf, "HLINKS" ) EQ 0 ) {
	  getParsedField( inBuf, sizeof( inBuf ), i+1 );
	  sb.st_nlink = (nlink_t)atoi( inBuf );
#ifdef DEBUG
	  if ( config->debug >= 5 )
	    printf( "DEBUG - HLINKS=%d\n", sb.st_nlink );
#endif
	} else if ( strcmp( inBuf, "BLOCKS" ) EQ 0 ) {
	  getParsedField( inBuf, sizeof( inBuf ), i+1 );
#ifdef OPENBSD
	  sb.st_blocks = (int64_t)atol( inBuf );
#else
	  sb.st_blocks = (blkcnt_t)atol( inBuf );
#endif
#ifdef DEBUG
	  if ( config->debug >= 5 )
	    printf( "DEBUG - BLOCKS=%ld\n", (long int)sb.st_blocks );
#endif
	} else if ( strcmp( inBuf, "MD5" ) EQ 0 ) {
	  getParsedField( inBuf, sizeof( inBuf ), i+1 );
	  /* convert hash string to binary */
	  for( dPos = 0, lPos = 0; dPos < MD5_HASH_LEN; dPos++, lPos+=2 ) {
	    hByte[0] = inBuf[lPos];
	    hByte[1] = inBuf[lPos+1];
	    digest[dPos] = strtoul( hByte, NULL, 16 );
	  }
#ifdef DEBUG
	  if ( config->debug >= 5 )
	    printf( "DEBUG - MD5=%s\n", hash2hex( digest, inBuf, MD5_HASH_LEN ) );
#endif
	} else {
	  fprintf( stderr, "ERR - Unknown field key [%s]\n", inBuf );
	}
      }

      /* merge the mode bits */
      sb.st_mode = tType | tPerm;

      /* load record into hash */
      processRecord( keyString, &sb, FILE_RECORD, digest );
    }
    /********* done with line *********/

#ifdef DEBUG
    if ( config->debug >= 7 )
      printf( "DEBUG - Read [%s]\n", inBuf );
#endif

  }

  deInitParser();

  fclose( inFile );

  printf( "Read [%ld] and loaded [%ld] lines from file about [%s] dated [%s]\n", (long int)count, (long int)compDirHash->totalRecords, compDir, startDate );

  return( FTW_CONTINUE );
}

# Version number and release date.
VERSION_NUMBER=0.5.3
RELEASE_DATE=2011-10-21      # in "date +%Y-%m-%d" format

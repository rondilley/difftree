/*****
 *
 * $Id: processDir.c,v 1.9 2011/07/16 22:25:26 rdilley Exp $
 *
 * Copyright (c) 2011, Ron Dilley
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *   - Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *   - Redistributions in binary form must reproduce the above copyright
 *     notice, this list of conditions and the following disclaimer in
 *     the documentation and/or other materials provided with the
 *     distribution.
 *   - Neither the name of Uberadmin/BaraCUDA/Nightingale nor the names of
 *     its contributors may be used to endorse or promote products derived
 *     from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 * FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 * HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 * SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED
 * TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *****/

/****
 *
 * includes
 *.
 ****/

#include "processDir.h"

/****
 *
 * local variables
 *
 ****/

PRIVATE char *cvsid = "$Id: processDir.c,v 1.9 2011/07/16 22:25:26 rdilley Exp $";

/****
 *
 * global variables
 *
 ****/

/****
 *
 * external variables
 *
 ****/

extern int errno;
extern char **environ;
extern struct hash_s *baseDirHash;
extern struct hash_s *compDirHash;
extern int diffIt;
extern int baseDirLen;
extern int compDirLen;
extern char *baseDir;
extern char *compDir;
extern Config_t *config;

/****
 * 
 * functions
 *
 ****/

static int display_info(const char *fpath, const struct stat *sb, int tflag, struct FTW *ftwbuf) {
  struct hashRec_s *tmpRec;
  struct stat *tmpSb;
  char tmpBuf[1024];
  char diffBuf[4096];
  struct tm *tmPtr;

  bzero( tmpBuf, sizeof( tmpBuf ) );
  bzero( diffBuf, sizeof( diffBuf ) );

  if ( diffIt ) {
    /* compare */
    if ( strlen( fpath ) <= compDirLen )
      return( 0 );

    if ( config->debug >=  5 )
      printf( "DEBUG - [%s]\n", fpath+compDirLen );

    if ( ( tmpRec = getHashRecord( baseDirHash, fpath+compDirLen ) ) EQ NULL ) {
      printf( "+ %s [%s]\n",
	      (tflag == FTW_D) ?   "d"   : (tflag == FTW_DNR) ? "dnr" :
	      (tflag == FTW_DP) ?  "dp"  : (tflag == FTW_F) ?   "f" :
	      (tflag == FTW_NS) ?  "ns"  : (tflag == FTW_SL) ?  "sl" :
	      (tflag == FTW_SLN) ? "sln" : "???",
	      fpath+compDirLen );
    } else {
#ifdef DEBUG
      if ( config->debug >= 3 )
	printf( "DEBUG - Found match, comparing metadata\n" );
#endif
      tmpSb = (struct stat *)tmpRec->data;
      if ( sb->st_size != tmpSb->st_size ) {
#ifdef HAVE_SNPRINTF
	snprintf( tmpBuf, sizeof( tmpBuf ), "s[%ld->%ld] ", (long int)tmpSb->st_size, (long int)sb->st_size );
#else
	sprintf( tmpBuf, "s[%ld->%ld] ", (long int)tmpSb->st_size, (long int)sb->st_size );
#endif

#ifdef HAVE_STRNCAT
	strncat( diffBuf, tmpBuf, sizeof( diffBuf ) );
#else
	strlcat( diffBuf, tmpBuf, sizeof( diffBuf ) );
#endif
      }
      if ( !config->quick ) {
	/* do more testing */

	/* uid/gid */
	if ( sb->st_uid != tmpSb->st_uid ) {
#ifdef HAVE_SNPRINTF
	  snprintf( tmpBuf, sizeof( tmpBuf ), "u[%d>%d] ", tmpSb->st_uid, sb->st_uid );
#else
	  sprintf( tmpBuf, "u[%d>%d] ", tmpSb->st_uid, sb->st_uid );
#endif
#ifdef HAVE_STRNCAT
          strncat( diffBuf, tmpBuf, sizeof( diffBuf ) );
#else
	  strlcat( diffBuf, tmpBuf, sizeof( diffBuf ) );
#endif
	}
	if ( sb->st_gid != tmpSb->st_gid ) {
#ifdef HAVE_SNPRINTF
	  snprintf( tmpBuf, sizeof( tmpBuf ), "g[%d>%d] ", tmpSb->st_gid, sb->st_gid );
#else
	  sprintf( tmpBuf, "g[%d>%d] ", tmpSb->st_gid, sb->st_gid );
#endif

#ifdef HAVE_STRNCAT
          strncat( diffBuf, tmpBuf, sizeof( diffBuf ) );
#else
	  strlcat( diffBuf, tmpBuf, sizeof( diffBuf ) );
#endif
	}

	/* file type */
	if ( ( sb->st_mode & S_IFMT ) != ( tmpSb->st_mode & S_IFMT ) ) {
#ifdef HAVE_SNPRINTF
	  snprintf( tmpBuf, sizeof( tmpBuf ), "t[%s->%s] ",
#else
	  sprintf( tmpBuf, "t[%s->%s] ",
#endif
		   ((tmpSb->st_mode & S_IFMT) == S_IFDIR) ?   "d"   : ((tmpSb->st_mode & S_IFMT) == S_IFSOCK) ? "sok" :
		   ((tmpSb->st_mode & S_IFMT) == S_IFBLK) ?  "blk"  : ((tmpSb->st_mode & S_IFMT) == S_IFREG) ?   "f" :
		   ((tmpSb->st_mode & S_IFMT) == S_IFCHR) ?  "chr"  : ((tmpSb->st_mode & S_IFMT) == S_IFLNK) ?  "sl" :
		   ((tmpSb->st_mode & S_IFMT) == S_IFIFO) ? "fifo" : "???",
		   ((sb->st_mode & S_IFMT) == S_IFDIR) ?   "d"   : ((sb->st_mode & S_IFMT) == S_IFSOCK) ? "sok" :
		   ((sb->st_mode & S_IFMT) == S_IFBLK) ?  "blk"  : ((sb->st_mode & S_IFMT) == S_IFREG) ?   "f" :
		   ((sb->st_mode & S_IFMT) == S_IFCHR) ?  "chr"  : ((sb->st_mode & S_IFMT) == S_IFLNK) ?  "sl" :
		   ((sb->st_mode & S_IFMT) == S_IFIFO) ? "fifo" : "???" );

#ifdef HAVE_STRNCAT
          strncat( diffBuf, tmpBuf, sizeof( diffBuf ) );
#else
	  strlcat( diffBuf, tmpBuf, sizeof( diffBuf ) );
#endif
	}

	/* permissions */
	if ( ( sb->st_mode & 0xffff ) != ( tmpSb->st_mode & 0xffff ) ) {
#ifdef HAVE_SNPRINTF
	  snprintf( tmpBuf, sizeof( tmpBuf ), "p[%c%c%c%c%c%c%c%c%c->%c%c%c%c%c%c%c%c%c] ",
#else
	  sprintf( tmpBuf, "p[%c%c%c%c%c%c%c%c%c->%c%c%c%c%c%c%c%c%c] ",
#endif
		   (tmpSb->st_mode & S_IRUSR ) ? 'r' : '-',
		   (tmpSb->st_mode & S_IWUSR ) ? 'w' : '-',
		   (tmpSb->st_mode & S_ISUID ) ? 's' : (tmpSb->st_mode & S_IXUSR) ? 'x' : '-',
		   (tmpSb->st_mode & S_IRGRP ) ? 'r' : '-',
		   (tmpSb->st_mode & S_IWGRP ) ? 'w' : '-',
		   (tmpSb->st_mode & S_ISGID ) ? 's' : (tmpSb->st_mode & S_IXGRP) ? 'x' : '-',
		   (tmpSb->st_mode & S_IROTH ) ? 'r' : '-',
		   (tmpSb->st_mode & S_IWOTH ) ? 'w' : '-',
		   (tmpSb->st_mode & S_ISVTX ) ? 's' : (tmpSb->st_mode & S_IXOTH) ? 'x' : '-',
		   (sb->st_mode & S_IRUSR ) ? 'r' : '-',
		   (sb->st_mode & S_IWUSR ) ? 'w' : '-',
		   (sb->st_mode & S_ISUID ) ? 's' : (sb->st_mode & S_IXUSR) ? 'x' : '-',
		   (sb->st_mode & S_IRGRP ) ? 'r' : '-',
		   (sb->st_mode & S_IWGRP ) ? 'w' : '-',
		   (sb->st_mode & S_ISGID ) ? 's' : (sb->st_mode & S_IXGRP) ? 'x' : '-',
		   (sb->st_mode & S_IROTH ) ? 'r' : '-',
		   (sb->st_mode & S_IWOTH ) ? 'w' : '-',
		   (sb->st_mode & S_ISVTX ) ? 's' : (sb->st_mode & S_IXOTH) ? 'x' : '-' );
#ifdef HAVE_STRNCAT
          strncat( diffBuf, tmpBuf, sizeof( diffBuf ) );
#else
	  strlcat( diffBuf, tmpBuf, sizeof( diffBuf ) );
#endif
	}

	if ( sb->st_mtime != tmpSb->st_mtime ) {
	  tmPtr = localtime( &tmpSb->st_mtime );
#ifdef HAVE_SNPRINTF
	  snprintf( tmpBuf, sizeof( tmpBuf ), "mt[%04d/%02d/%02d@%02d:%02d:%02d->",
#else
	  sprintf( tmpBuf, "mt[%04d/%02d/%02d@%02d:%02d:%02d->",
#endif
		   tmPtr->tm_year+1900, tmPtr->tm_mon+1, tmPtr->tm_mday,
		   tmPtr->tm_hour, tmPtr->tm_min, tmPtr->tm_sec );
#ifdef HAVE_STRNCAT
          strncat( diffBuf, tmpBuf, sizeof( diffBuf ) );
#else
	  strlcat( diffBuf, tmpBuf, sizeof( diffBuf ) );
#endif
	  tmPtr = localtime( &sb->st_mtime );
#ifdef HAVE_SNPRINTF
	  snprintf( tmpBuf, sizeof( tmpBuf ), "%04d/%02d/%02d@%02d:%02d:%02d] ",
#else
	  sprintf( tmpBuf, "%04d/%02d/%02d@%02d:%02d:%02d] ",
#endif
		   tmPtr->tm_year+1900, tmPtr->tm_mon+1, tmPtr->tm_mday,
		   tmPtr->tm_hour, tmPtr->tm_min, tmPtr->tm_sec );
#ifdef HAVE_STRNCAT
          strncat( diffBuf, tmpBuf, sizeof( diffBuf ) );
#else
	  strlcat( diffBuf, tmpBuf, sizeof( diffBuf ) );
#endif
	}
      }
      if ( config->hash ) {
	if ( tflag EQ FTW_F ) {
	  /* md5 files */
	}
      }
      if ( strlen( diffBuf ) ) {
	printf( "%s%s [%s]\n", diffBuf,
		(tflag == FTW_D) ?   "d"   : (tflag == FTW_DNR) ? "dnr" :
		(tflag == FTW_DP) ?  "dp"  : (tflag == FTW_F) ?   "f" :
		(tflag == FTW_NS) ?  "ns"  : (tflag == FTW_SL) ?  "sl" :
		(tflag == FTW_SLN) ? "sln" : "???",
		fpath );
      }
#ifdef DEBUG
      else {
	if ( config->debug > 4 )
	  printf( "DEBUG - Record matches\n" );
      }
#endif

    }
    tmpSb = (struct stat *)XMALLOC( sizeof (struct stat) );
    XMEMCPY( (void *)tmpSb, (void *)sb, sizeof( struct stat ) );
    addUniqueHashRec( compDirHash, fpath+compDirLen, strlen( fpath+compDirLen ), tmpSb );
  } else {
    if ( strlen( fpath ) <= baseDirLen )
      return( 0 );
    /* store file stat */
    tmpSb = (struct stat *)XMALLOC( sizeof (struct stat) );
    XMEMCPY( (void *)tmpSb, (void *)sb, sizeof( struct stat ) );
#ifdef DEBUG
    if ( config->debug >= 5 )
      printf( "DEBUG - Adding RECORD\n" );
#endif
    addUniqueHashRec( baseDirHash, fpath+baseDirLen, strlen( fpath+baseDirLen ), tmpSb );
    /* check to see if the hash should be grown */
    baseDirHash = dyGrowHash( baseDirHash );
  }

  return( 0 );
}

/****
 *
 * process directory tree
 *
 ****/

PUBLIC int processDir( char *dirStr ) {
  printf( "Processing dir [%s]\n", dirStr );

  if ( nftw( dirStr, display_info, 20, FTW_PHYS ) == -1 ) {
    fprintf( stderr, "ERR - Unable to open dir [%s]\n", dirStr );
    return ( FAILED );
  }

  if ( config->debug >= 2 )
    printf( "DEBUG - Finished processing dir [%s]\n", dirStr );

  return( TRUE );
}

/****
 *
 * check for missing files
 *
 ****/

int findMissingFiles( const struct hashRec_s *hashRec ) {
  struct hashRec_s *tmpRec;
   struct stat *tmpSb;
   int tflag;

#ifdef DEBUG
  if ( config->debug >= 3 )
    printf( "DEBUG - Searching for [%s]\n", hashRec->keyString );
#endif

  if ( ( tmpRec = getHashRecord( compDirHash, hashRec->keyString ) ) EQ NULL ) {
    tmpSb = (struct stat *)hashRec->data;
    tflag = tmpSb->st_mode & S_IFMT;
    printf( "- %s [%s]\n", 
	    (tflag == S_IFDIR) ?   "d"   : (tflag == S_IFSOCK) ? "sok" :
	    (tflag == S_IFBLK) ?  "blk"  : (tflag == S_IFREG) ?   "f" :
	    (tflag == S_IFCHR) ?  "chr"  : (tflag == S_IFLNK) ?  "sl" :
	    (tflag == S_IFIFO) ? "fifo" : "???",
	    hashRec->keyString );
  }
#ifdef DEBUG
  else
    if ( config->debug >= 4 )
      printf( "DEBUG - Record found [%s]\n", hashRec->keyString );
#endif

  /* can use this later to interrupt traversing the hash */
  return FALSE;
}

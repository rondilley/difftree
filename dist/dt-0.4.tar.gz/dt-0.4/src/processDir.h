/*****
                          processDir.h  -  process dir header
                             -------------------
    begin                : Tue Jun 21 2011
    copyright            : (C) 2011 by Ron Dilley
    email                : ron.dilley@uberadmin.com
 *****/

/*****
 *
 *   This program is free software; you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation; either version 2 of the License, or
 *   (at your option) any later version.
 *
 *****/

#ifndef PROCESSDIR_DOT_H
#define PROCESSDIR_DOT_H

/****
 *
 * defines
 *
 ****/

/****
 *
 * includes
 *
 ****/

#ifdef HAVE_CONFIG_H
# include <config.h>
#endif

#include <sysdep.h>

#ifndef __SYSDEP_H__
# error something is messed up
#endif

#include <stdio.h>
#include <common.h>
#include "util.h"
#include "mem.h"
#include "hash.h"

/****
 *
 * consts & enums
 *
 ****/

/****
 *
 * typedefs & structs
 *
 ****/

/****
 *
 * function prototypes
 *
 ****/

PUBLIC int processDir( char *dirStr );
int findMissingFiles( const struct hashRec_s *hashRec );

#endif /* PROCESSDIR_DOT_H */
